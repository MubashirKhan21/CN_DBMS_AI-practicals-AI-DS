use DBMS;
select *from Persons;
