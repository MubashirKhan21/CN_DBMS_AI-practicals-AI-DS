package sql;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;

public class sql {

	public static void main(String[] args) throws SQLException {
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/DBMS","root","1234");
		//2)create statement
		Statement stmt=con.createStatement();
		String s="INSERT INTO Persons  (PersonId,LastName,FirstName,Address,City)VALUES(102,'Mulla','Salma','Peth','Nashik')";
		String s1="INSERT INTO Persons  (PersonId,LastName,FirstName,Address,City)VALUES(105,'Joshi','Reema','Warje','Mumbai')";
		String s3="INSERT INTO Persons  (PersonId,LastName,FirstName,Address,City)VALUES(106,'naiknavare','omkar','narhe ','pune')";
		String s4="INSERT INTO Persons  (PersonId,LastName,FirstName,Address,City)VALUES(110,'RUtuja','neharkar','Peth','Nashik')";
	//stmt.execute(s);
  //  stmt.execute(s1);
	stmt.execute(s3);
	con.close();
	System.out.println("\nQUERY EXECUTED");
	}

}